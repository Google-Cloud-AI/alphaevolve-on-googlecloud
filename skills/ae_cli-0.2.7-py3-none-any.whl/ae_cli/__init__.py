"""AlphaEvolve CLI package."""
