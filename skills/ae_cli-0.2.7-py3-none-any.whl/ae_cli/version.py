"""Version information for AlphaEvolve CLI."""

__version__ = "0.2.7"
