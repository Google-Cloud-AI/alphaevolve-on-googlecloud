"""Lock cache for AlphaEvolve CLI."""

from __future__ import annotations

from . import config


class LockCache:
  """Caches lock tokens for programs."""

  def __init__(self, profile_name: str):
    self.profile_name = profile_name
    self.cache_key = f"lock_cache_{profile_name}"
    self._locks: dict[str, str] = {}
    self.load()

  def load(self) -> None:
    """Loads locks from disk cache."""
    data = config.get_cache(self.cache_key, ttl_seconds=2**30)
    if data and isinstance(data, dict):
      self._locks = data

  def save(self) -> None:
    """Saves locks to disk cache."""
    config.save_cache(self.cache_key, self._locks)

  def add(self, program_name: str, lock_token: str) -> None:
    """Adds a lock token for a program."""
    self._locks[program_name] = lock_token
    self.save()

  def get(self, program_name: str) -> str | None:
    """Retrieves a lock token for a program."""
    return self._locks.get(program_name)
